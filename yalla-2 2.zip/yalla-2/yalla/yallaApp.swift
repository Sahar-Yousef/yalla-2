//
//  yallaApp.swift
//  yalla
//
//  Created by Noura Alqahtani on 08/10/2023.
//

import SwiftUI

@main
struct yallaApp: App {
   
    var body: some Scene {
        
        WindowGroup {
           
                SwiftUIViewHome()
                      
        
            
            
        }
    }
}
